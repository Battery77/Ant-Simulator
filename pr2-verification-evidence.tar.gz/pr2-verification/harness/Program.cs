using System.Reflection;
using System.Buffers.Binary;
using AntSim.Core.Scent;
using AntSim.Core.Simulation;
using AntSim.Core.Serialization;
using AntSim.Core.Worlds;

class Program
{
    static void Check(bool ok, string message) { if (!ok) throw new Exception(message); }
    static void Wait(ManualResetEventSlim e) => Check(e.Wait(TimeSpan.FromSeconds(5)), "event timeout");
    static void Done(Task t) => Check(SpinWait.SpinUntil(() => t.IsCompleted, TimeSpan.FromSeconds(5)), "task timeout");
    static World World() => new(new WorldConfig(5, 5, 8));
    static ScentSettings Settings(double dp = .952) => new() { TickSeconds = 1, Types = new[] { new ScentTypeSettings("x", "X", null, .012, dp, 0, 0) } };
    static SimulationSession Session() => new(World(), Settings());
    static byte[] MapBytes(World w) { using var m = new MemoryStream(); MapSerializer.Save(w,m); return m.ToArray(); }
    static byte[] ExpBytes(SimulationSession s) { using var m = new MemoryStream(); ExperimentSerializer.Save(s,m); return m.ToArray(); }
    static FieldInfo Field(string n) => typeof(SimulationHost).GetField(n, BindingFlags.Instance | BindingFlags.NonPublic)!;
    static string State(SimulationHost h) { lock(Field("_gate").GetValue(h)!) return Field("_state").GetValue(h)!.ToString()!; }
    static int Main(string[] args)
    {
        try {
            Console.WriteLine($"Mode={args[0]}, runtime={Environment.Version}, core={typeof(SimulationHost).Assembly.Location}");
            switch(args[0]) { case "t1-hook": T1(true); break; case "t1-control": T1(false); break; case "t2": T2(); break; case "t3": T3(); break; case "regression": Regression(); break; default: throw new Exception("unknown mode"); }
            Console.WriteLine("ALL OBSERVATION ASSERTIONS PASSED (not a claim of defect-free code)"); return 0;
        } catch(Exception e) { Console.Error.WriteLine(e); return 1; }
    }
    static void T1(bool hook)
    {
        using var entered = new ManualResetEventSlim(); using var releaseFirst = new ManualResetEventSlim();
        using var boundary = new ManualResetEventSlim(); using var releaseBoundary = new ManualResetEventSlim();
        var host = new SimulationHost(Session()); Task? dispose = null; int calls=0; bool disposedAtCallback=false;
        try {
            var first = host.RunExclusiveAsync(_ => { entered.Set(); Wait(releaseFirst); return 7; });
            Wait(entered);
            if(hook) Field("TestHook").SetValue(host, (Action<string>)(point => { if(point=="before-dequeue") { boundary.Set(); Wait(releaseBoundary); } }));
            var pending = host.RunExclusiveAsync(_ => { Interlocked.Increment(ref calls); disposedAtCallback=(bool)Field("_disposed").GetValue(host)!; return 42; });
            if(hook) { releaseFirst.Set(); Wait(boundary); }
            Check(calls==0 && !pending.IsCompleted, "target must still be pending");
            dispose=Task.Run(host.Dispose);
            Check(SpinWait.SpinUntil(()=>State(host)=="Stopping", TimeSpan.FromSeconds(5)), "Stopping not observed");
            Console.WriteLine($"before release: state={State(host)}, callbackCount={calls}, target={pending.Status}, dispose={dispose.Status}");
            if(hook) releaseBoundary.Set(); else releaseFirst.Set();
            Done(first); Done(pending); Done(dispose);
            Console.WriteLine($"after: first={first.Status}, callbackCount={calls}, disposedAtCallback={disposedAtCallback}, target={pending.Status}, dispose={dispose.Status}, state={State(host)}, failure={host.Failure}");
            Check(first.Status==TaskStatus.RanToCompletion && dispose.Status==TaskStatus.RanToCompletion && host.Failure is null, "completion failure");
            Check(hook ? calls==1 && disposedAtCallback && pending.Status==TaskStatus.RanToCompletion : calls==0 && pending.IsCanceled, "unexpected observation");
        } finally { releaseFirst.Set(); releaseBoundary.Set(); dispose ??= Task.Run(host.Dispose); Done(dispose); }
    }
    static void T2()
    {
        foreach(var c in new[] { ("boundary", .952, true, ScentState.MaxConcentration), ("near-below", .951999, true, ScentState.MaxConcentration), ("no-passage", .952, false, ScentState.MaxConcentration), ("low", .952, true, 1f) }) {
            var w=World(); if(c.Item3) Check(w.TrySetPassage(2,2,true)==WorldError.None,"passage");
            var settings=Settings(c.Item2); Check(settings.Validate().Count==0,"settings invalid");
            var s=new SimulationSession(w,settings); var f=s.Scent.MutableField(0,LayerId.Surface);
            foreach(int i in new[]{7,11,13,17}) f[i]=c.Item4;
            s.Scent.MutableField(0,LayerId.Nest)[12]=c.Item4;
            Check(s.Scent.AllValuesInSupportedRange(),"invalid initial");
            var bytes=ExpBytes(s); var loaded=ExperimentSerializer.Load(new MemoryStream(bytes));
            Check(loaded.ComputeStateHash()==s.ComputeStateHash(),"initial roundtrip"); loaded.Step();
            float v=loaded.Scent.Get(0,LayerId.Surface,2,2); int bits=BitConverter.SingleToInt32Bits(v), maxbits=BitConverter.SingleToInt32Bits(ScentState.MaxConcentration);
            bool range=loaded.Scent.AllValuesInSupportedRange(); Exception? error=null; using var second=new MemoryStream();
            try { ExperimentSerializer.Save(loaded,second); second.Position=0; Check(ExperimentSerializer.Load(second).ComputeStateHash()==loaded.ComputeStateHash(),"second roundtrip"); } catch(Exception e) {error=e;}
            Console.WriteLine($"{c.Item1}: CFL={settings.Types[0].MaxOutflowFraction(1):R}, firstSaveLoad=OK bytes={bytes.Length}, tick={loaded.Tick}, center={v:R}, exact={(double)v:G17}, bits=0x{bits:X8}, maxExact={(double)ScentState.MaxConcentration:G17}, maxBits=0x{maxbits:X8}, ULPdiff={bits-maxbits}, range={range}, secondBytes={second.Length}, secondSaveLoad={(error is null ? "OK" : error.GetType().Name+": "+error.Message)}");
            if(c.Item1=="boundary") Check(!range && bits-maxbits==1 && error is InvalidOperationException && second.Length==0,"boundary not reproduced");
            else Check(range && error is null,"control failed");
        }
    }
    static void Regression()
    {
        var valid = ExpBytes(Session());
        // Parse the tiny valid header to find the first embedded-map length.
        using var br = new BinaryReader(new MemoryStream(valid));
        br.BaseStream.Position=36; int types=br.ReadInt32();
        for(int i=0;i<types;i++) { int n=br.ReadInt32();br.ReadBytes(n); n=br.ReadInt32();br.ReadBytes(n);br.ReadBytes(34); }
        int lengthOffset=(int)br.BaseStream.Position;
        var huge=valid[..(lengthOffset+4)]; BinaryPrimitives.WriteInt32LittleEndian(huge.AsSpan(lengthOffset),1_500_000_000);
        var truncated=valid[..^16];
        var map=MapBytes(World())[..25]; BinaryPrimitives.WriteInt32LittleEndian(map.AsSpan(12),16384); BinaryPrimitives.WriteInt32LittleEndian(map.AsSpan(16),16384);
        foreach(var c in new[]{("huge-embedded",huge,false),("truncated-scent",truncated,false),("header-only-map",map,true)})
        foreach(bool seekable in new[]{true,false}) {
            using Stream stream=seekable?new MemoryStream(c.Item2):new Watched(c.Item2);
            long before=GC.GetAllocatedBytesForCurrentThread();Exception? error=null;
            try { if(c.Item3)MapSerializer.Load(stream);else ExperimentSerializer.Load(stream); }catch(Exception e){error=e;}
            long allocated=GC.GetAllocatedBytesForCurrentThread()-before;
            Console.WriteLine($"{c.Item1} seek={seekable}, inputBytes={c.Item2.Length}, allocated={allocated}, error={error?.GetType().Name}: {error?.Message}");
            Check(error is MapFormatException && allocated<1024*1024,"cheap rejection failed");
        }
    }
    static void T3()
    {
        var wa=World(); var wb=World(); wb.TrySetPassage(2,2,true);
        var sa=new SimulationSession(wa,Settings()); var sb=new SimulationSession(wb,Settings()); sb.Step();
        foreach(var kind in new[]{"map","exp"}) {
            byte[] a=kind=="map"?MapBytes(wa):ExpBytes(sa), b=kind=="map"?MapBytes(wb):ExpBytes(sb);
            ulong ha=kind=="map"?wa.ComputeContentHash():sa.ComputeStateHash(), hb=kind=="map"?wb.ComputeContentHash():sb.ComputeStateHash();
            Func<Stream,ulong> load=kind=="map"?s=>MapSerializer.Load(s).ComputeContentHash():s=>ExperimentSerializer.Load(s).ComputeStateHash();
            byte[] both=a.Concat(b).ToArray();
            using var seek=new MemoryStream(both); Check(load(seek)==ha && seek.Position==a.Length,"seek A"); Check(load(seek)==hb && seek.Position==both.Length,"seek B");
            Console.WriteLine($"{kind} seek two records OK: A={a.Length} B={b.Length}");
            using var ns=new Watched(both); Check(load(ns)==ha,"nonseek A hash");
            Console.WriteLine($"{kind} nonseek first: consumed={ns.Consumed}/{both.Length}, boundary={a.Length}, reads={ns.Calls}, trace={ns.Trace}");
            Check(ns.Consumed==both.Length,"not overconsumed");
            Exception? second=null; try {load(ns);} catch(Exception e){second=e;}
            Console.WriteLine($"{kind} nonseek second: {second?.GetType().Name}: {second?.Message}; reads={ns.Calls}"); Check(second is MapFormatException,"second should fail EOF");
            using var guard=new Watched(a,a.Length); Exception? over=null; try{load(guard);}catch(Exception e){over=e;}
            Console.WriteLine($"{kind} guard: consumed={guard.Consumed}, reads={guard.Calls}, boundaryAttempts={guard.Overreads}, exception={over?.GetType().Name}, trace={guard.Trace}");
            Check(over is IOException && guard.Overreads==1,"guard not triggered");
            var invalid=new byte[4096]; using var bad=new Watched(invalid); Exception? magic=null; try{load(bad);}catch(Exception e){magic=e;}
            Console.WriteLine($"{kind} bad magic: consumed={bad.Consumed}, reads={bad.Calls}, exception={magic?.GetType().Name}: {magic?.Message}, trace={bad.Trace}");
            Check(magic is MapFormatException && bad.Consumed==invalid.Length,"bad magic observation");
            using var badSeek=new MemoryStream(invalid); try{load(badSeek);}catch(MapFormatException){} Check(badSeek.Position==8,"seek early magic rejection");
            Console.WriteLine($"{kind} bad magic seek consumed={badSeek.Position}");
        }
    }
}
sealed class Watched(byte[] bytes, int? boundary=null) : Stream
{
    public int Consumed {get;private set;} public int Calls {get;private set;} public int Overreads {get;private set;}
    readonly List<string> trace=new(); public string Trace=>string.Join(";",trace);
    public override int Read(byte[] buffer,int offset,int count)=>Read(buffer.AsSpan(offset,count));
    public override int Read(Span<byte> buffer) {
        Calls++; if(boundary is int end && Consumed>=end) {Overreads++;trace.Add($"at={Consumed} request={buffer.Length} THROW");throw new IOException("read beyond first checksum");}
        int n=Math.Min(buffer.Length,bytes.Length-Consumed); if(boundary is int limit)n=Math.Min(n,limit-Consumed);
        bytes.AsSpan(Consumed,n).CopyTo(buffer);trace.Add($"at={Consumed} request={buffer.Length} returned={n}"); Consumed+=n;return n;
    }
    public override bool CanRead=>true; public override bool CanWrite=>false; public override bool CanSeek=>false;
    public override long Length=>throw new NotSupportedException(); public override long Position{get=>throw new NotSupportedException();set=>throw new NotSupportedException();}
    public override void Flush(){} public override long Seek(long o,SeekOrigin s)=>throw new NotSupportedException(); public override void SetLength(long v)=>throw new NotSupportedException(); public override void Write(byte[] b,int o,int c)=>throw new NotSupportedException();
}

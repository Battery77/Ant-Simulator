#!/usr/bin/env bash
set -euo pipefail
if [ -f /workspace/.ant-tools/env.sh ]; then source /workspace/.ant-tools/env.sh; fi
cd "$(dirname "$0")"
mkdir -p logs
for cfg in Debug Release; do
 dotnet build harness/Repro.csproj -c "$cfg" --nologo > "logs/build-$cfg.log" 2>&1
 for mode in t1-control t2 t3 regression; do
  timeout 20 dotnet "harness/bin/$cfg/net8.0/Repro.dll" "$mode" 2>&1 | tee "logs/$mode-$cfg.log"
 done
 dotnet build hook-harness/Repro.csproj -c "$cfg" --nologo > "logs/build-hook-$cfg.log" 2>&1
 timeout 20 dotnet "hook-harness/bin/$cfg/net8.0/Repro.dll" t1-hook 2>&1 | tee "logs/t1-hook-$cfg.log"
done
